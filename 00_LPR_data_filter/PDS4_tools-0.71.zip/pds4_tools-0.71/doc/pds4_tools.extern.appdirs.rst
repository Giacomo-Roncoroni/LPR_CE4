pds4_tools.extern.appdirs module
================================

.. automodule:: pds4_tools.extern.appdirs
    :members:
    :undoc-members:
    :show-inheritance:
