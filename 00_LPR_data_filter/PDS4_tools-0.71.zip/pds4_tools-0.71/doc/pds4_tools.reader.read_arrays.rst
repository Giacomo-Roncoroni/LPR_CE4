pds4_tools.reader.read_arrays module
====================================

.. automodule:: pds4_tools.reader.read_arrays

Functions
---------

.. autosummary::

    read_array
    read_array_data
    flat_data_to_list


Details
-------

.. autofunction:: read_array
.. autofunction:: read_array_data
.. autofunction:: flat_data_to_list
