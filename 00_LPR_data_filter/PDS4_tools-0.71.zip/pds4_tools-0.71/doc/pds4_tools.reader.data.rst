pds4_tools.reader.data module
=============================

.. automodule:: pds4_tools.reader.data

Classes
-------

.. autosummary::
    DataList
    DataArray
    DataNdarray

Functions
---------

.. autosummary::
    get_data_class

Details
-------

.. autofunction:: get_data_class

.. autoclass:: DataList
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: DataArray
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: DataNdarray
    :members:
    :undoc-members:
    :show-inheritance:

