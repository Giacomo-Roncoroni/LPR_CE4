pds4_tools.reader.read_tables module
====================================

.. automodule:: pds4_tools.reader.read_tables

Functions
---------

.. autosummary::

    read_table
    read_table_data
    table_data_size_check

Details
-------

.. autofunction:: read_table
.. autofunction:: read_table_data
.. autofunction:: table_data_size_check
